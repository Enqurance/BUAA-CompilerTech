package ClassFile;

public class TokenType {
    public static int Ident = 1;
    public static int ReserveWords = 2;
    public static int Digit = 3;
    public static int Note = 4;
    public static int FormatString = 5;
}
