package ClassFile.MipsInstr;

public class Instr {
}
