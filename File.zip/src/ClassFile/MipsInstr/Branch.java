package ClassFile.MipsInstr;

public class Branch extends Instr{
}
