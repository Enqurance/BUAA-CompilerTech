package ClassFile.MipsInstr;

public class StackInstr extends Instr {
}
