package ClassFile.InterCode;

public class ArrayStore extends ICode{
}
