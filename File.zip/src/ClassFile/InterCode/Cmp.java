package ClassFile.InterCode;

public class Cmp extends ICode{
}
