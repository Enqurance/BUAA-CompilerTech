package ClassFile.InterCode;

public class ArrayLoad extends ICode{
}
