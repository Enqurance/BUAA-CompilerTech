package ClassFile.InterCode;

public class ICode {
    public void PrintString() {

    }

    public String GetLSym() {
        return "ICodeParent";
    }

    public String GetContext() {
        return "ICodeContext";
    }
}
