package ClassFile.InterCode;

public class Jump extends ICode{
}
